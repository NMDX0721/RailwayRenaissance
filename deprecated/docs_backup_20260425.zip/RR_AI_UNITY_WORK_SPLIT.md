# RR：哪些 Unity 工作适合 AI，哪些必须手动

> 这份文档基于对 Unity 社区讨论、官方资料与实践经验的整理。
> 目标不是证明 AI 不能做 Unity，而是给 RR 项目建立一个**更稳的协作边界**。

---

## 一句话结论

在 **没有强 Unity Editor 内部集成** 的前提下：

- **AI 适合做：代码、结构、数据、规划、规则、辅助工具**
- **人更适合做：Hierarchy、Scene 组织、Prefab 组装、Inspector 拖引用、最终场景确认**

原因很简单：
Unity 很多关键工作不只是“写文件”，而是依赖 **Editor 当前状态、Hierarchy 结构、Prefab/Scene 序列化、Inspector 引用关系**。
这些内容对 AI 来说天然更脆弱。

---

## 为什么 RR 要这样分工

查询里反复出现的几个现实问题：

1. **Scene / Prefab 是脆弱的序列化资产**
   - Unity 场景与 prefab 常以 YAML 形式保存
   - 即使只是插入、移动一个对象，也可能引起大片文本变化

2. **Scene / Prefab merge 一直是高风险区**
   - 社区与官方支持文章都长期讨论 scene/prefab merge conflict
   - `m_RootOrder`、对象顺序、嵌套 prefab、引用关系都容易让 diff 很难读

3. **Inspector 引用和场景对象绑定很依赖编辑器上下文**
   - AI 会写脚本，但不一定知道当前场景里真实存在什么对象
   - 没有 Editor 内部集成时，AI 很容易“以为自己知道”，实际上是在猜

4. **自动维护 hierarchy 的脚本/工具本身也可能把场景搞乱**
   - 社区讨论里也有人明确不建议用自动监视脚本去强行纠正 scene hierarchy

---

## 适合 AI 的 Unity 工作

这些工作更偏“文本、逻辑、结构、规则”，适合交给 AI：

### 1. 代码实现
- C# gameplay 逻辑
- 管理器脚本
- 数据读取与保存
- 调度/订单/结算逻辑
- 工具类、辅助类、状态机

### 2. 数据结构设计
- JSON 数据格式
- ScriptableObject 字段设计
- C# data class
- 配置 schema
- 测试样例数据

### 3. 规划与文档
- 任务拆解
- 模块边界
- 验收标准
- 开发顺序
- 技术路线说明

### 4. Editor 辅助代码
- 自定义菜单
- 一键创建模板对象的 Editor 工具
- 数据校验工具
- 缺引用检查器
- 命名规范检查脚本

### 5. 非关键自动生成
- 初版代码骨架
- 非关键 prefab 组件清单
- 场景搭建步骤说明
- UI 层级建议稿

---

## 必须优先手动的 Unity 工作

这些工作建议由你人工最终创建/确认：

### 1. 关键 Scene Hierarchy 搭建
- 根节点结构
- 主要父子关系
- 场景对象归类
- 命名最终确认

### 2. 关键 Prefab 组装
- 关键对象 prefab 的最终结构
- prefab 嵌套关系
- 场景内实例与 prefab 的边界

### 3. Inspector 引用拖拽
- SerializedField 手动绑定
- 场景对象引用
- UI Button / Event 绑定
- 关键 manager 引用关系

### 4. UI 场景与布局最终摆放
- Canvas 层级
- RectTransform 布局
- 锚点/偏移检查
- 可视化排版确认

### 5. 最终场景验收
- Play 一次看对象是否齐
- 引用是否丢失
- prefab override 是否异常
- hierarchy 是否混乱

---

## RR 项目的推荐分工

### OpenClaw（规划师）负责
- 写任务包
- 写验收标准
- 控制范围
- 定义系统边界
- 产出搭建规范与实现说明

### Trae（实现者）负责
- 写代码
- 写数据结构
- 写 editor 辅助工具
- 写组件清单
- 写“该怎么搭”的步骤文档

### 你（人工）负责
- 创建关键实体
- 搭 hierarchy
- 建关键 prefab
- 拖 Inspector 引用
- 做最终场景确认

---

## RR 的实际执行规则

以后默认按下面执行：

### 可以交给 AI / Trae 的
- 新系统脚本
- 数据模型
- 订单系统逻辑
- 调度逻辑
- 地图图结构逻辑
- 工具脚本
- 搭建说明文档
- 检查/校验脚本

### 不默认交给 AI 的
- 主场景 hierarchy 最终搭建
- 核心 prefab 最终结构
- 关键 Inspector 手工引用
- 关键 UI 事件绑定
- 场景内对象的最终摆位和确认

---

## 如果以后接入 Unity Editor 内部集成

边界可以放宽一点，但也不要完全放开。

即便有内部集成，AI 也更适合：
- 读取 hierarchy 状态
- 检查缺失组件/引用
- 执行低风险批量操作
- 创建模板对象
- 输出修复建议

但以下仍建议人工最终确认：
- 主场景结构
- 关键 prefab
- 关键引用绑定
- UI 最终层级与交互

---

## RR 项目的工作原则

### 原则 1：关键实体由人拍板
关键场景对象可以参考 AI 建议，但最终创建与确认由人完成。

### 原则 2：AI 更像结构师和施工图助手
AI 更适合产出：
- 结构图
- 脚本
- 字段表
- 组件清单
- 搭建步骤

而不是直接替人完成全部场景搭建。

### 原则 3：能代码化的尽量代码化
如果某些重复配置可以通过：
- Editor 工具
- 校验脚本
- 模板生成器
来降低手工负担，那让 AI 写这些工具是划算的。

### 原则 4：关键场景改动宁可慢一点，也不要脆
RR 现在处于早期，最怕的是 scene/prefab 结构反复坏掉。
稳定比一时省事更重要。

---

## 当前最终结论

对于 RR：

**AI 负责“写规则、写代码、写结构、写工具、写说明”。**

**你负责“建关键实体、配 hierarchy、挂引用、做最终确认”。**

这是目前最稳、最不容易把 Unity 项目搞乱的协作方式。

---

## 参考方向（本次查询）

- Unity AI Assistant Manual  
  https://docs.unity3d.com/Packages/com.unity.ai.assistant@latest/
- Unity Support: scene/prefab conflict merging  
  https://support.unity.com/hc/en-us/articles/207332543-What-are-the-solutions-to-scene-prefab-conflict-merging
- Unity blog: Author scenes and prefabs with version control  
  https://unity.com/blog/author-scenes-and-prefabs-with-verson-control
- Manu's Techblog: Merge Conflicts in Unity - How to avoid them?  
  https://manuel-rauber.com/2023/01/25/merge-conflicts-in-unity-how-to-avoid-them/
- Unity Discussions: Scene merge conflicts because of m_RootOrder  
  https://discussions.unity.com/t/scene-merge-conflicts-because-of-m_rootorder/564174
- Unity Discussions: How to use Hierarchy Prefab  
  https://discussions.unity.com/t/how-to-use-hierarchy-prefab/901790
