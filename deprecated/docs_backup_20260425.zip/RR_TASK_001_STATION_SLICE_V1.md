# RR 任务包 001：车站场景第一版（Station Slice V1）

## 任务定位
这是 RR 在新协作模式下的第一份正式开发任务包。

目标不是做完整铁路经营系统，
而是先做出一个 **可进入、可看懂、可验证资源装载与基础布局是否成立的车站切片场景**。

---

## 任务目标
产出一个 **车站场景第一版**，满足以下最低要求：

1. 能进入场景
2. 能看到基础车站区域
3. 能看到地图/地块基础铺设
4. 能看到列车占位图出现在合理位置
5. 能看到最基础 UI 原型元素
6. 场景结构清晰，便于后续继续迭代

这不是最终美术版本，
也不是完整可玩 Demo，
而是 **第一版站点切片原型**。

---

## 本任务的范围

### 任务内要做的
- 使用现有已导入资源搭出一个基础车站切片
- 使用现有列车占位图 / prefab 放置一列测试列车
- 使用现有 UI prototype 资源做最基础界面占位
- 让场景具备清晰的 hierarchy 分层建议
- 确保后续能继续往订单 / 发车 / UI 信息面板方向扩展

### 本任务内不做的
- 不做完整订单系统
- 不做正式调度系统
- 不做完整 NPC / 新闻 / 政治系统
- 不做精修 UI
- 不做最终美术风格统一
- 不做复杂交互逻辑
- 不追求“正式可发布”，只追求“原型站得住”

---

## 可用资源（已确认）

### 环境
- `Assets/Art/Environment/Tilesets/tiny-town_tilemap_packed.png`

### 列车
- `Assets/Art/Vehicles/Prototype/train_placeholder.png`
- `Assets/Prefabs/TrainPlaceholder.prefab`

### UI
- `Assets/Art/UI/Prototype/button_primary.png`
- `Assets/Art/UI/Prototype/button_secondary.png`
- `Assets/Art/UI/Prototype/icon_checkmark.png`
- `Assets/Art/UI/Prototype/icon_cross.png`
- `Assets/Art/UI/Prototype/input_rectangle.png`
- `Assets/Art/UI/Prototype/slider_horizontal.png`

### 音效（本任务可暂不接）
- `Assets/Audio/UI/ui_click.ogg`
- `Assets/Audio/UI/ui_confirm.ogg`
- `Assets/Audio/UI/ui_error.ogg`
- `Assets/Audio/UI/ui_switch.ogg`

### 现有场景
- 旧的 `Assets/Scenes/StationSlice_01.unity` 与 `Assets/Scenes/StationSlice_Validation.unity` 已删除，不再作为起点。
- 本任务改为：**从一个新的干净场景开始手工搭建车站切片第一版。**

---

## 推荐场景目标样子

第一版场景建议至少出现这些视觉层：

1. **地面/底图层**
   - 使用 tilemap 或最简单地块拼接
   - 先形成一个“车站区域”而不是纯空白背景

2. **站台/轨道表达层**
   - 不要求完整铁路网络
   - 但至少要有“这是站点切片”的空间感

3. **列车占位层**
   - 放 1 列列车占位图
   - 位置应显得像停在站台或轨道旁

4. **UI 占位层**
   - 至少出现一个主按钮区
   - 一个信息框或输入框占位
   - 一个状态/确认图标占位

---

## Hierarchy 建议（由你人工搭建/确认）

以下是推荐结构，不要求完全一致，但建议接近：

- `StationSliceRoot`
  - `World`
    - `Ground`
    - `Tracks`
    - `Platform`
    - `Props`
    - `TrainRoot`
  - `Managers`
    - `GameManager`
    - `UIManager`
    - `AudioManager`（可先保留占位）
  - `Canvas`
    - `TopBar`
    - `RightPanel`
    - `BottomActions`
    - `StatusHints`

说明：
- **Hierarchy 最终创建与确认由你来做**
- Trae / AI 不默认替你拍板关键场景实体结构

---

## 新协作模式下的分工

### 你负责
- 在 Unity 中最终创建 / 确认关键 hierarchy
- 拖关键 Inspector 引用
- 确认场景里哪些对象真实保留
- 人眼确认布局是否顺眼

### 我负责
- 拆任务
- 控范围
- 写验收标准
- 规划下一步任务

### Trae 负责
- 根据本任务包整理实现思路
- 编写低风险脚本/辅助代码
- 说明资源如何绑定
- 输出修改说明
- 不擅自扩大任务范围

---

## 建议 Trae 执行的内容

Trae 适合做：

1. 检查现有脚本是否已经支持场景初始化
2. 整理场景需要的对象清单
3. 如果需要，补最小安全脚本：
   - 场景初始化
   - 资源绑定
   - TrainPlaceholder 显示
   - UI 原型资源绑定
4. 输出一份“你在 Unity 里如何手工搭建”的步骤说明

Trae 不应擅自做：
- 最终 hierarchy 拍板
- 关键 Inspector 引用的最终决定
- 大规模直接改脆弱 scene 结构

---

## 你现在实际动手时的推荐顺序

### 步骤 1
新建一个干净场景，作为新的车站切片起点。

建议命名：
- `Assets/Scenes/StationSlice_V1.unity`

### 步骤 2
你手工确认 hierarchy 骨架：
- World
- TrainRoot
- Canvas
- Managers

### 步骤 3
把现有资源先放上去：
- 地块 tileset
- 列车占位 prefab
- 最基础 UI 按钮/框体

### 步骤 4
确认画面达到“能读懂”的程度：
- 看得出这是车站
- 看得出有车
- 看得出有基础 UI

---

## 验收标准

满足以下条件，才算本任务完成：

### A. 场景层面
- 能正常打开并运行新的目标场景
- 场景中不再是纯空白
- 至少有一列 train placeholder 出现在场景里

### B. 结构层面
- hierarchy 有基本分层
- World / UI / Managers 至少能区分
- 不出现明显混乱堆叠命名

### C. 资源层面
- 已确认的 MVP 资源被实际用到
- 不是只存在文件夹里没进场景

### D. 可扩展性层面
- 后续可以自然接入订单/UI/发车逻辑
- 没有把第一版场景做成一次性死结构

### E. 汇报层面
Trae 完成后必须说明：
- 改了哪些文件
- 场景里增加了哪些对象
- 哪些部分需要你手工确认
- 下一步最合理的任务是什么

---

## 完成后的下一任务候选

完成车站场景第一版后，下一步优先从这三项中选一项：

1. **车站 UI 信息区第一版**
2. **列车占位移动/到站表现第一版**
3. **最小订单展示与指派 UI 第一版**

---

## 当前一句话要求

先不要追求“大而全”，
只要把 **车站场景第一版做得可进入、可辨认、可继续迭代** 就够了。
