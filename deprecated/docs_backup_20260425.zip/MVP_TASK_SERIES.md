# Railway Revival MVP 连续任务链（恢复模式）

> 规则：虽然这是系列任务，但仍按 **单任务执行后停下** 的默认执行。每完成一项，都先复盘，再等待人工 / main 放行下一项。

## Task 01 — 建立 MVP 主文档（已完成）
**目标**
- 明确 MVP 核心玩法、最小闭环、非目标、验证方式

**产出**
- `docs/MVP_RECOVERY.md`

**完成标准**
- 测试者能仅通过文档理解：
  - 这一版到底要做什么
  - 先不做什么
  - 该如何验收

## Task 02 — 清理 RR↔Trae stale backlog / superseded 污染（已由 main 在桥接层完成）
**目标**
- 清掉 inbox 中遗留旧 `todo`，让 worker 状态不再被 `stale_backlog_skipped` 污染

**结果**
- 此项已由 main 在桥接层处理完成，无需在本回合重复执行

**完成标准**
- inbox 中不再残留远古 `todo`
- worker-status 不再以 stale backlog 作为主要 reason

## Task 03 — 建立 MVP 执行看板文档（已完成）
**目标**
- 把 MVP 当前阶段拆成：文档层 / 协作层 / 实现层 三层看板

**产出**
- `docs/MVP_BOARD.md`

**完成标准**
- 每一层都能看出：待做 / 进行中 / 已完成 / 阻塞点

## Task 04 — 建立安全实现策略文档（已完成）
**目标**
- 明确 Unity 后续只允许的安全路径：Editor 内创建、编辑器脚本、干净新场景

**产出**
- `docs/UNITY_SAFE_RECOVERY.md`

**完成标准**
- 团队后续不会再把 raw `.unity` YAML 当主修复路径
- 对“高风险操作”有清晰停手条件

## Task 05 — 建立 MVP 验收清单（已完成）
**目标**
- 把未来人工测试改成固定 checklist，减少“看起来像完成，其实不可测”

**产出**
- `docs/MVP_SMOKE_CHECKLIST.md`

**完成标准**
- 至少覆盖：进入场景、UI 是否出现、按钮是否响应、EndDay 是否推进、反馈是否可读

## Task 06 — 建立第一版干净场景重建方案（已完成）
**目标**
- 不是直接改场景，而是先定义“如果重建，该最小重建哪些对象/组件”

**产出**
- `docs/CLEAN_SCENE_REBUILD_PLAN.md`

**完成标准**
- 能明确列出：必须对象、必须组件、创建顺序、验证顺序

## 当前最优先顺序
1. Task 01 — MVP 主文档（已完成）
2. Task 02 — stale backlog / superseded 清理（已由 main 完成）
3. Task 03 — MVP 执行看板（已完成）
4. Task 04 — Unity 安全恢复策略（已完成）
5. Task 05 — MVP 验收清单（已完成）
6. Task 06 — 干净场景重建方案

## 当前 blocker
- Unity 旧验证场景存在结构性损坏历史
- 后续虽然已有文档边界、验收清单与重建蓝图，但仍未进入真正的 Editor 内安全重建执行阶段

## 当前建议
- 下一步不应再扩文档，而应在人工 / main 明确放行后，按 `docs/CLEAN_SCENE_REBUILD_PLAN.md` 进入 Unity Editor 内的最小重建执行
