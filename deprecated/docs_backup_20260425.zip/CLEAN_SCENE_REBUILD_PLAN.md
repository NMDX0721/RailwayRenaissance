# Railway Revival 干净场景重建蓝图（最小可测版本）

> 目标：给人一份可以在 **Unity Editor 内一步步照着做** 的最小重建蓝图。
> 这不是最终关卡设计，也不是完整游戏架构，而是为了恢复一个 **最小可测版本**。

---

## 一、重建目标
重建一个干净、可信、可人工冒烟测试的最小场景，使测试者能够完成：

1. 进入场景
2. 看见基本界面
3. 做一次最小选择
4. 点击 `结束当天`
5. 看到明确反馈

只要能稳定完成这 5 件事，就达到当前 MVP 的最小可测目标。

---

## 二、重建原则
1. **只在 Unity Editor 内创建**
2. **每次只补一小层，补完就验证**
3. **优先可测，不追求好看**
4. **对象/组件必须少而明确**
5. **任何一步一旦出现结构异常，立即停手，不继续堆对象**

---

## 三、场景分层

## A. 必须有（Must Have）
这些对象/组件缺一不可，否则不进入下一步。

### 1. 场景根
- Scene Root（可为空根对象，命名建议：`RR_MVP_Root`）

### 2. 相机层
- `Main Camera`
  - 组件：
    - `Transform`
    - `Camera`
  - 推荐配置：
    - Position：`(0, 0, -10)`
    - Projection：`Orthographic`
    - Size：`5`

### 3. UI 根层
- `Canvas`
  - 组件：
    - `RectTransform`
    - `Canvas`
    - `CanvasScaler`
    - `GraphicRaycaster`
- `EventSystem`
  - 组件：
    - `EventSystem`
    - `StandaloneInputModule`（或当前输入系统等价组件）

### 4. 最小界面层
- `TopBar`
  - 至少包含：
    - `DayText`
    - `StatusText`
- `RightPanel`
  - 至少包含：
    - `DescriptionText`
- `BottomBar`
  - 至少包含两个可操作按钮：
    - 一个“决策按钮”
    - 一个“结束当天”按钮

### 5. 最小逻辑承载层
- 一个场景控制对象，命名可保守为：
  - `MVPController`
- 它只需要承载最小闭环所需逻辑：
  - 当前天数
  - 当前选项文本
  - 点击决策后的反馈文本
  - 点击 `结束当天` 后的推进与反馈

### 6. 最小可见场景层
至少有 3 个可见占位对象：
- `Ground`
- `Track`
- `Train`

它们不要求真实美术，只要求在 Game 里明显可见，用于告诉测试者：
- 场景不是空的
- 当前是铁路小站题材

---

## B. 可后补（Can Add Later）
这些内容不是最小可测闭环必需，可以在基础闭环通过后再加。

- `Platform`
- `StationSign`
- `Passengers`
- `Bench`
- `Shelter`
- `StreetLight`
- 更完整的右侧公告 / 待办 / 简报区
- 6 个完整一级按钮
- SummaryPanel / 日报总结详细面板

这些对象都属于“增强可信感 / 完整度”的层，不是当前第一轮必须项。

---

## 四、推荐重建顺序（按 Editor 执行）

### Step 1：只建相机
创建：
- `Main Camera`

验证点：
- Game 视图不再出现 `No cameras rendering`
- Inspector 中能明确看到 `Camera` 组件

通过标准：
- 相机存在且可渲染

---

### Step 2：只建 Canvas 与 EventSystem
创建：
- `Canvas`
- `EventSystem`

验证点：
- Inspector 中能明确看到 `Canvas` 组件
- `Canvas` 在 Hierarchy 中结构正常
- 没有 missing component

通过标准：
- UI 根层可信存在

---

### Step 3：只建最小界面骨架
创建：
- `TopBar`
  - `DayText`
  - `StatusText`
- `RightPanel`
  - `DescriptionText`
- `BottomBar`
  - `PrimaryActionButton`
  - `EndDayButton`

验证点：
- Game 里能看到顶部 / 右侧 / 底部三块区域
- 至少能看到 2 个按钮
- 文本能正常显示，不是 missing script / missing component

通过标准：
- 测试者能说出“我现在看到了状态区、说明区、操作区”

---

### Step 4：只建最小可见场景对象
创建：
- `Ground`
- `Track`
- `Train`

推荐实现：
- 用最简单、最稳定的占位方式
- 不依赖复杂 prefab
- 不追求真实美术

验证点：
- Game 里能看见这 3 个对象
- 相机视野里位置关系清楚
- 没有对象只剩 Transform 的情况

通过标准：
- 场景不再是 UI 浮在空白背景上

---

### Step 5：接入最小闭环逻辑
创建 / 挂接：
- `MVPController`

最小逻辑只需要支持：
1. 初始显示：
   - `DayText = 第 1 天`
   - `StatusText = 当前功能: 无`
   - `DescriptionText = 点击按钮开始测试`
2. 点击 `PrimaryActionButton` 后：
   - `StatusText` 变化
   - `DescriptionText` 变化
3. 点击 `EndDayButton` 后：
   - 天数从 `第 1 天` → `第 2 天`
   - `DescriptionText` 或等价反馈区出现“已推进一天”之类可判定结果

验证点：
- 点击后有明确文本变化
- 结束当天后有明确推进

通过标准：
- 测试者能完成一次“看状态 → 做选择 → 结束当天 → 看到反馈”

---

### Step 6：通过最小冒烟清单
使用：
- `docs/MVP_SMOKE_CHECKLIST.md`

验证点：
- 按 checklist 逐项记录
- 结论必须明确是 `PASS / FAIL / ESCALATE`

通过标准：
- 不是“看起来差不多”，而是有记录、有结论

---

## 五、每一步的停手条件
任一步出现以下情况时，立即停：

- missing script / missing component
- 关键对象只剩 Transform
- `No cameras rendering`
- 对象名存在，但 Inspector 中没有关键组件
- 需要靠外部直接拼 `.unity` YAML 才能继续

一旦触发：
- 不进入下一步
- 先记录当前停在哪一步
- 升级到人工 / main 决定下一动作

---

## 六、最小逻辑假设边界
当前蓝图只采用**最保守、可验证**的玩法表达，不假设复杂系统已经存在。

因此这里的最小逻辑假设是：
- 一个决策按钮就足够代表“做选择”
- 一个结束当天按钮就足够代表“推进结算”
- 反馈以文本变化为主即可

当前**不假设**：
- 完整 6 按钮逻辑一定一次做完
- 完整经济系统已存在
- 完整日报系统已存在
- 完整人物 / 新闻 / AI 反馈已存在

---

## 七、Out of Scope（当前不做）
为了避免蓝图膨胀，本轮明确不做：

- 复杂站台布景
- 完整 6 功能全逻辑
- 完整日报 / 新闻 / 待办系统
- NPC / 乘客 AI
- 复杂动画
- 音效系统
- prefab 体系整理
- 旧损坏场景强行抢救
- 外部 raw `.unity` YAML 修场景

---

## 八、最小完成定义
当以下条件全部成立时，可认为“干净场景最小重建蓝图已被正确执行”：

1. 相机可信
2. Canvas 可信
3. 最小界面可信
4. 至少 1 个决策按钮可响应
5. `结束当天` 可推进
6. 至少 1 个反馈区发生可判定变化
7. 通过 `MVP_SMOKE_CHECKLIST.md` 的最小闭环测试

---

## 九、一句话执行口令
**先在 Unity Editor 内按“相机 → Canvas/EventSystem → 最小 UI → 最小场景对象 → 最小闭环逻辑 → 冒烟测试”顺序重建；每补一层就验证，不允许一口气堆成半成品。**
