# Railway Revival MVP 执行看板

> 当前模式：**MVP 文档恢复模式**
> 默认执行规则：**单任务完成后停下，等待人工 / main 放行**

## 1. 文档层
### 已完成
- `docs/MVP_RECOVERY.md`
  - 定义了 MVP 核心玩法、最小闭环、非目标、验证方式
- `docs/MVP_TASK_SERIES.md`
  - 定义了恢复模式下的顺序任务链
- `docs/MVP_BOARD.md`
  - 建立当前推进看板

### 进行中
- 无

### 待做
- `docs/UNITY_SAFE_RECOVERY.md`
  - 目标：明确 Unity 安全恢复路径与禁区
- `docs/MVP_SMOKE_CHECKLIST.md`
  - 目标：固定人工验收步骤
- `docs/CLEAN_SCENE_REBUILD_PLAN.md`
  - 目标：定义干净场景最小重建方案

### 文档层验收标准
- 新人只看 docs 即可理解：
  1. 当前项目做什么
  2. 当前阶段不做什么
  3. 下一步该做什么
  4. 如何验收

## 2. 协作层
### 当前状态
- RR↔Trae 默认工作模式：**单任务执行后强制停下**
- stale backlog / superseded 污染：**已由 main 在桥接层处理完成**
- gate / worker / inbox / outbox 的目标状态：
  - gate：真实反映 hold/open
  - worker：不再被 stale backlog 噪声污染
  - inbox：只保留有效候选
  - outbox：按任务单独产出结果

### 已完成
- 默认停链规则已明确
- stale backlog 污染已由 main 处理

### 待做
- 后续每项文档 / 实现任务，都要继续遵守“完成一项 → 复盘 → 停下”
- 如果后面需要恢复自动化可见性，应优先补文档/状态说明，而不是重新无限连跑

### 协作层验收标准
- 任一任务结束后，不自动衔接下一条
- 状态文件可读，不以旧任务噪声为主
- 当前阻塞点和下一步始终清楚

## 3. 实现层
### 当前策略
- **先不硬修高风险 Unity 场景**
- **不再使用 raw `.unity` YAML 作为主修复路径**
- 优先推进：
  1. 文档
  2. 验收规范
  3. 安全恢复方案
  4. 干净重建方案

### 已知高风险区
- 旧 `StationSlice_Validation.unity` 有结构性损坏历史
- 直接外部拼场景 YAML 已被证明不可靠

### 低风险优先事项
- 写清楚安全恢复规范
- 写清楚人工冒烟检查单
- 写清楚干净重建的最小对象/组件清单

### 实现层验收标准
- 后续进入 Unity 层时，不再依赖危险路径
- 任一实现动作都能映射回 MVP 最小闭环
- 验证顺序先于资产扩充

## 4. 当前 blocker
1. 高风险场景恢复路径仍不能直接使用
2. 尚未产出统一的 Unity 安全恢复规范文档
3. 尚未产出固定的人工验收 checklist

## 5. 当前最优先顺序
1. `docs/MVP_RECOVERY.md` ✅
2. `docs/MVP_BOARD.md` ✅
3. `docs/UNITY_SAFE_RECOVERY.md`
4. `docs/MVP_SMOKE_CHECKLIST.md`
5. `docs/CLEAN_SCENE_REBUILD_PLAN.md`

## 6. 下一步建议
下一项优先做：
- **`docs/UNITY_SAFE_RECOVERY.md`**

原因：
- 它能直接给后续所有实现动作划边界
- 能防止再次回到 raw `.unity` YAML 修场景的高风险路径
- 能为后续干净场景重建和人工验收提供统一前提
